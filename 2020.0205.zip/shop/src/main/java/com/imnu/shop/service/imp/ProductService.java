package com.imnu.shop.service.imp;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.imnu.shop.pojo.Product;

public interface ProductService {

	List<Product> findProductByPage(int page);

	void addProduct(Product product);

	Product findProductById(int pid);

	void editProduct(Product product);

	List<Product> findAllHotProduct();

	List<Product> findAllNewProduct();

	List<Product> findProductsByfid(int fid);

}
