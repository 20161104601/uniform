package com.imnu.shop.pojo;

public class Categorysecond {
    private Integer id;

    private String sname;

    private Integer fid;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public Integer getFid() {
        return fid;
    }

    public void setFid(Integer fid) {
        this.fid = fid;
    }

	@Override
	public String toString() {
		return "Categorysecond [id=" + id + ", sname=" + sname + ", fid=" + fid + "]";
	}
    
}