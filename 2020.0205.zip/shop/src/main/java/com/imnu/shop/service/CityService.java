package com.imnu.shop.service;

import java.util.List;

import com.imnu.shop.pojo.City;

public interface CityService {
	public List<City> findCitiesByPid(int pid);

}
