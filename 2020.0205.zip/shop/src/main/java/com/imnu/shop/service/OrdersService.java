package com.imnu.shop.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.imnu.shop.pojo.Orders;

public interface OrdersService {

	void addOrders(Orders orders);

}
