package com.imnu.shop.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;

import com.imnu.shop.mapper.CategoryMapper;
import com.imnu.shop.pojo.Category;
import com.imnu.shop.pojo.CategoryExample;
import com.imnu.shop.service.CategoryService;
@Service
@Transactional
public class CategoryServiceImp implements CategoryService {
	@Autowired
	private CategoryMapper categoryMapper;
	
	public List<Category> findAllCategory() {
		return categoryMapper.selectByExample(new CategoryExample());
	}

	public void saveCategory(Category category) {
		categoryMapper.insertSelective(category);
	}

	public void deleteCategory(int id) {
		categoryMapper.deleteByPrimaryKey(id);
		
	}

	public Category findCategoryById(int id) {
		return categoryMapper.selectByPrimaryKey(id);
	}

	public void updateCategory(Category category) {
		categoryMapper.updateByPrimaryKey(category);
		
	}

	@Override
	public List<Category> findCategoryAndSecond() {
		
		return categoryMapper.findCategoryAndSecond();
	}
	
}
