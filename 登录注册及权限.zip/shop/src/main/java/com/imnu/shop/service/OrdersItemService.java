package com.imnu.shop.service;

import java.util.List;

import com.imnu.shop.pojo.Orderitem;

public interface OrdersItemService {

	void addOrdersItem(List<Orderitem> list);

}
