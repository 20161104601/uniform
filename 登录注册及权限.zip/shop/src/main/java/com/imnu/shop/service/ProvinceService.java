package com.imnu.shop.service;

import java.util.List;

import com.imnu.shop.pojo.Province;

public interface ProvinceService {
	List<Province> findAllProvince();
}
