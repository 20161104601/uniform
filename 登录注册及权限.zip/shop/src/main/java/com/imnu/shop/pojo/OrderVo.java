package com.imnu.shop.pojo;

import java.util.List;

public class OrderVo {
	
	private Orders orders;
	
	private List<Orderitem> orderitemList;

	public Orders getOrders() {
		return orders;
	}

	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	public List<Orderitem> getOrderitemList() {
		return orderitemList;
	}

	public void setOrderitemList(List<Orderitem> orderitemList) {
		this.orderitemList = orderitemList;
	}

}
