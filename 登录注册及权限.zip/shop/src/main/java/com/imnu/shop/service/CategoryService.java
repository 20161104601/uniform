package com.imnu.shop.service;

import java.util.List;

import com.imnu.shop.pojo.Category;

public interface CategoryService {
	List<Category> findAllCategory();

	void saveCategory(Category category);

	void deleteCategory(int id);

	Category findCategoryById(int id);

	void updateCategory(Category category);

	List<Category> findCategoryAndSecond();

}
