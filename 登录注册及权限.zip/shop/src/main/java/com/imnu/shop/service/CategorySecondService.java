package com.imnu.shop.service;

import java.util.List;

import com.imnu.shop.pojo.Categorysecond;

public interface CategorySecondService {

	List<Categorysecond> findAllCategorySecond();

	void insertCategorySecondService(Categorysecond categorysecond);

	Categorysecond findCategorysecondById(int id);

	void deleteCategorysecondById(int id);

	List<Categorysecond> findAllCategorySecondById(int fid);

}
