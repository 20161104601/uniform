package com.imnu.shop.service.imp;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageInfo;
import com.imnu.shop.mapper.ProductMapper;
import com.imnu.shop.pojo.Product;
import com.imnu.shop.pojo.ProductExample;
@Service
@Transactional
public class ProductServiceImp implements ProductService{
	@Autowired
	private ProductMapper productMapper;

	public List<Product> findProductByPage(int page) {
		return productMapper.selectByExample(new ProductExample());
	}

	@Override
	public void addProduct(Product product) {
		product.setPdate(new Date());
		productMapper.insertSelective(product);
	}

	@Override
	public Product findProductById(int pid) {
		return productMapper.selectByPrimaryKey(pid);
	}

	@Override
	public void editProduct(Product product) {
		product.setPdate(new Date());
		ProductExample example=new ProductExample();
		example.createCriteria().andPidEqualTo(product.getPid());
		productMapper.updateByExample(product, example);
	}

	@Override
	public List<Product> findAllHotProduct() {
		ProductExample example=new ProductExample();
		example.createCriteria().andIsHotEqualTo((byte)1);
		return productMapper.selectByExample(example);
	}

	@Override
	public List<Product> findAllNewProduct() {
		return productMapper.findProductByDate();
	}

	@Override
	public List<Product> findProductsByfid(int fid) {
		return productMapper.findProductsByfid();
	}

}
