# SpringBoot网上商城
> 使用SpringBoot 集成Spring-data-jpa,Druid连接池,thymeleaf模板实现的一个简单网上商城项目，包含后台管理

Q 2118119173