package com.imnu.shop.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.imnu.shop.mapper.CategoryMapper;
import com.imnu.shop.mapper.CategorysecondMapper;
import com.imnu.shop.pojo.Categorysecond;
import com.imnu.shop.pojo.CategorysecondExample;
import com.imnu.shop.service.CategorySecondService;
@Service
@Transactional
public class CategorySecondServiceImp implements CategorySecondService {
	@Autowired
	private CategorysecondMapper categorysecondMapper;
	public List<Categorysecond> findAllCategorySecond() {
		List<Categorysecond> list = categorysecondMapper.selectByExample(new CategorysecondExample());
		return list.size()==0?null:list;
	}
	public void insertCategorySecondService(Categorysecond categorysecond) {
		categorysecondMapper.insertSelective(categorysecond);
	}
	public Categorysecond findCategorysecondById(int id) {
		return categorysecondMapper.selectByPrimaryKey(id);
	}
	public void deleteCategorysecondById(int id) {
		categorysecondMapper.deleteByPrimaryKey(id);
	}
	@Override
	public List<Categorysecond> findAllCategorySecondById(int fid) {
		CategorysecondExample example=new CategorysecondExample();
		example.createCriteria().andFidEqualTo(fid);
		return categorysecondMapper.selectByExample(example);
	}

}
