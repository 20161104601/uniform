package com.imnu.shop.service;

import com.imnu.shop.pojo.Adminuser;

public interface AdminUserService {
	public Adminuser login(Adminuser user);

}
