package com.imnu.shop.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.imnu.shop.pojo.Categorysecond;
import com.imnu.shop.service.CategorySecondService;

@Controller
@RequestMapping("/admin/categorysecond")
public class AdminCategorySecondController {
	@Autowired
	private CategorySecondService categorySecondService;
	@RequestMapping("/findAllCategorySecond")
	public ModelAndView findAllCategorySecond() {
		List<Categorysecond> list=categorySecondService.findAllCategorySecond();
		ModelAndView mv = new ModelAndView();
		mv.addObject("categorysecondList", list);
		mv.setViewName("admin/categorysecond/list");
		return mv;
	}
	
	@RequestMapping("/findAllCategorySecondAjax")
	@ResponseBody
	public List<Categorysecond> findAllCategorySecondAjax() {
		List<Categorysecond> list=categorySecondService.findAllCategorySecond();
		return list;
	}
	@RequestMapping("/findCategorysecondByfidAjax")
	@ResponseBody
	public List<Categorysecond> findCategorysecondByfidAjax(int fid){
		List<Categorysecond> list=categorySecondService.findAllCategorySecondById(fid);
		return list;
	}
	@RequestMapping("/saveCategorysecond")
	public String saveCategorysecond(Categorysecond categorysecond) {
		categorySecondService.insertCategorySecondService(categorysecond);
		return "redirect:findAllCategorySecond.action";
	}
	@RequestMapping("/findCategorysecond")
	public ModelAndView findCategorysecond(int  id) {
		Categorysecond categorysecond=categorySecondService.findCategorysecondById(id);
		ModelAndView mv = new ModelAndView();
		mv.addObject("categorysecond", categorysecond);
		mv.setViewName("admin/categorysecond/edit");
		return mv;
	}
	@RequestMapping("/deleteCategorysecond")
	public String deleteCategorysecond(int id) {
		categorySecondService.deleteCategorysecondById(id);
		return "redirect:findAllCategorySecond.action";
	}

}
