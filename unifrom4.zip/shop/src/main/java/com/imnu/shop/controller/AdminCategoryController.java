package com.imnu.shop.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.imnu.shop.pojo.Category;
import com.imnu.shop.service.CategoryService;

@Controller
@RequestMapping("/admin/category")
public class AdminCategoryController {
	@Autowired
	private CategoryService categoryService;
	@RequestMapping("/findAllCategory")
	public ModelAndView findAllCategory(){
		List<Category> list = categoryService.findAllCategory();
		ModelAndView mv = new ModelAndView();
		mv.addObject("categoryList", list);
		mv.setViewName("admin/category/list");
		return mv;
	}
	
	@RequestMapping("/findAllCategoryAjax")
	@ResponseBody
	public List<Category> findAllCategoryAjax(){
		List<Category> list = categoryService.findAllCategory();
		return list;
	}
	@RequestMapping("/saveCategory")
	public 	String saveCategory(Category category) {
		 
		categoryService.saveCategory(category);
		return "redirect:findAllCategory.action";
	}
	
	
	@RequestMapping("/deleteCategory")
	public String deleteCategory(int id) {
		categoryService.deleteCategory(id);
		return "redirect:findAllCategory.action";
	}
	
	@RequestMapping("/findCategoryById")
	public ModelAndView findCategoryById(int id) {
		Category category=categoryService.findCategoryById(id);
		ModelAndView mv = new ModelAndView();
		mv.addObject("category", category);
		mv.setViewName("admin/category/edit");
		return mv;
	}
	@RequestMapping("/updateCategory")
	public String updateCategory(Category category) {
		categoryService.updateCategory(category);
		return "redirect:findAllCategory.action";
	}
	@RequestMapping("/findCategoryAndSecond")
	@ResponseBody
	public List<Category> findCategoryAndSecond() {
		List<Category> list=categoryService.findCategoryAndSecond();
		System.out.println(list);
		return list;
	}
}
