package com.imnu.shop.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.imnu.shop.pojo.User;
import com.imnu.shop.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	public UserService userService;
	@RequestMapping("/login")
	public ModelAndView login(User user,HttpSession session) {
		//System.out.println(user.getUsername()+"+"+user.getPwd());
		User u = userService.login(user);
 		ModelAndView mv = new ModelAndView();
 		//ModelAndView addObject方法向前台页面传值    添加模型数据 可以是任意的POJO对象
 		mv.addObject("user", u);
 		session.setAttribute("list", u);
 		//设置逻辑视图名，视图解析器会根据该名字解析到具体的视图页面
 		System.out.println(u.getUsername());
 		if(user.getUsername().equals("admin")) {
 			mv.setViewName("admin/login/home");	
 		}else {
 			mv.setViewName("admin/jsp/index");
 		}
		return mv;
	}
	
	@RequestMapping("/register")
	public ModelAndView register(User user ,MultipartFile img1,HttpSession session) {
		System.out.println("er");
		String result=uploadMultipartFile(img1);
		System.out.println(result);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("login");
		if(result!="error") {
			userService.register(user);
		}
		else
		{
			mv.addObject("result",result);
		}
		return mv;
	}
	@RequestMapping("/verifyname")
	public void VerifyName(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws Exception
	{
		String username = request.getParameter("username");
		PrintWriter out = response.getWriter();
		//trim() 去除字符串的头尾空格
		if(username.trim().equals(""))
		{
			out.print(2);//2是不能为空
		}
		else {
			int sum = userService.VerifyName(username);
			if(sum==0)
			{
				out.print(1);//1用户名已存在
			}
			else
			{
				out.print("error");//用户名可以用
			}
		}
	}
	@RequestMapping("/upload")
	public String uploadMultipartFile(MultipartFile img1) {
		String filename = img1.getOriginalFilename();//原文件名
		System.out.println(filename);
		File dest = new File("C:\\Users\\Public\\Pictures",filename);
		try {
			img1.transferTo(dest);
			return filename;
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return "error";
		
	}
	

}

