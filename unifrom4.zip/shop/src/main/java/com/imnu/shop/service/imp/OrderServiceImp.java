package com.imnu.shop.service.imp;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.imnu.shop.pojo.Orders;
import com.imnu.shop.service.OrdersService;

@Service
@Transactional
public class OrderServiceImp implements OrdersService{

	@Override
	public void addOrders(Orders orders) {
		
	}

}
