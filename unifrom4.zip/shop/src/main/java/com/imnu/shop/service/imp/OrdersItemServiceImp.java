package com.imnu.shop.service.imp;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.imnu.shop.pojo.Orderitem;
import com.imnu.shop.service.OrdersItemService;
@Service
@Transactional
public class OrdersItemServiceImp implements OrdersItemService{

	@Override
	public void addOrdersItem(List<Orderitem> list) {
		
	}

}
