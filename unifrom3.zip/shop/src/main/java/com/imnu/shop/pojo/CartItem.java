package com.imnu.shop.pojo;

import java.io.Serializable;

/**
 * 购物项:
 */
public class CartItem implements Serializable{
	// 商品对象
	private Product product;
	// 数量
	private Integer count;
	// 小计
	private Double subtotal;
	
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	
	public Double getSubtotal() {
		subtotal=count * product.getShopPrice();
		return  subtotal;
	}
	public void setSubtotal(Double subtotal) {
		this.subtotal = subtotal;
	}
	
	
}
