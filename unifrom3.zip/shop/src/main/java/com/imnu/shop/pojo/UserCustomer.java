package com.imnu.shop.pojo;

public class UserCustomer extends User{
	private Location loc;

	public Location getLoc() {
		return loc;
	}

	public void setLoc(Location loc) {
		this.loc = loc;
	}

	@Override
	public String toString() {
		return "UserCustomer [loc=" + loc + ", getId()=" + getId() + ", getUsername()=" + getUsername() + ", getPwd()="
				+ getPwd() + ", getBirthday()=" + getBirthday() + ", getLocation()=" + getLocation() + ", getName()="
				+ getName() + ", getEmail()=" + getEmail() + ", getPhone()=" + getPhone() + ", getWeixin()="
				+ getWeixin() + ", getQq()=" + getQq() + ", getImg()=" + getImg() + "]";
	}

}
