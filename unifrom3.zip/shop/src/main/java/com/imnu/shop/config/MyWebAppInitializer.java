package com.imnu.shop.config;

import java.nio.charset.StandardCharsets;

import javax.servlet.FilterRegistration;
import javax.servlet.MultipartConfigElement;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration.Dynamic;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

//相当于web.xml
public class MyWebAppInitializer extends AbstractAnnotationConfigDispatcherServletInitializer{
	// 加载Spring IOC 配置
	@Override
	protected Class<?>[] getRootConfigClasses() {
		return new Class<?>[] {};
	}

	// 加载bean
	@Override
	protected Class<?>[] getServletConfigClasses() {
		return new Class<?>[] { BeanConfig.class };
	}

	// DispatcherServlet拦截请求配置
	@Override
	protected String[] getServletMappings() {
		return new String[] { "*.action" };
//		return new String[] { "/" };
	}

	@Override
	protected void customizeRegistration(Dynamic registration) {
		registration.setMultipartConfig( // 通过重载customizeRegistration()方法来配置multipart的具体细节
				new MultipartConfigElement("C:\\Users\\Public\\Pictures", 2097152, 4194304, 0));
		// 设置写入的临时路径
		// 上传单个文件的最大容量（字节为单位），默认无限制。
		// 整个multipart请求的最大容量（字节为单位），默认无限制。
		// 在上传的过程中，如果文件大小达到了一个指定的最大容量，将会写入到临时文件路劲中。默认为0，也就是上传的文件都会写入到磁盘上。
	}

//	@Override
//	public void onStartup(ServletContext servletContext) throws ServletException {
//		FilterRegistration.Dynamic encodingFilter = servletContext.addFilter("encodingFilter",
//				CharacterEncodingFilter.class);
//		encodingFilter.setInitParameter("encoding", String.valueOf(StandardCharsets.UTF_8));
//		encodingFilter.setInitParameter("forceEncoding", "true");
//		encodingFilter.addMappingForUrlPatterns(null, false, "/*");
//	}

}
