package com.imnu.shop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.imnu.shop.mapper.UserMapper;
import com.imnu.shop.pojo.User;
import com.imnu.shop.pojo.UserExample;

@Service
@Transactional
public class UserServiceImp implements UserService {
	@Autowired
	public UserMapper userMapper;
	public User login(User user) {
		UserExample example= new UserExample();
		example.createCriteria().andUsernameEqualTo(user.getUsername()).andPwdEqualTo(user.getPwd());	
		List<User> list=userMapper.selectByExample(example);
		return list==null?null:list.get(0);
	}
	//注册
	public void register(User user) {
		userMapper.insertSelective(user); 
	}
	//注册验证
	public int VerifyName(String username) {
		UserExample example=new UserExample();
		example.createCriteria().andUsernameEqualTo(username);
		List<User> list = userMapper.selectByExample(example);
		if(list.isEmpty())
		{
			return 1;
		}
		else {
			return 0;
		}
	}

}
