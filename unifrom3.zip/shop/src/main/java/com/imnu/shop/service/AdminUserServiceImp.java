package com.imnu.shop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.imnu.shop.mapper.AdminuserMapper;
import com.imnu.shop.pojo.Adminuser;
import com.imnu.shop.pojo.AdminuserExample;
@Service
@Transactional
public class AdminUserServiceImp implements AdminUserService{
	@Autowired
	private AdminuserMapper adminuserMapper;

	public Adminuser login(Adminuser user) {
		AdminuserExample example=new AdminuserExample();
		List<Adminuser> list = adminuserMapper.selectByExample(example);
		return list.size()==0?null:list.get(0);
	}

}
