package com.imnu.shop.controller;

import java.io.File;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.imnu.shop.pojo.Category;
import com.imnu.shop.pojo.Product;
import com.imnu.shop.service.imp.ProductService;

@Controller
@RequestMapping("/admin/product")
public class AdminProductController {
	@Autowired
	public ProductService productService;

	@RequestMapping("/findProductByPage")
	/* @ResponseBody */
	public ModelAndView findProductByPage(@RequestParam(required = true, defaultValue = "1") int page) {
		// PageHelper插件 select * from product limit 6,10;
		PageHelper.startPage(page, 3);
		List<Product> list = productService.findProductByPage(page);


		PageInfo<Product> pageInfo = new PageInfo<>(list);
//		new JsonResult(pageInfo);
		ModelAndView mv = new ModelAndView();
		mv.addObject("pageInfo", pageInfo);

		mv.setViewName("admin/product/list");
		return mv;
	}

	@RequestMapping("addProduct")
	public String addProduct(Product product, MultipartFile pictureFile) {
		if (!"".contentEquals(pictureFile.getOriginalFilename())) {
			String result = uploadMultipartFile(pictureFile);
			if (!("error".equals(result))) {
				product.setImage(result);
				productService.addProduct(product);
			}
		}

		return "redirect:findProductByPage.action";
	}
	@RequestMapping("/findProductById")
	public ModelAndView findProductById(int pid) {
		Product product=productService.findProductById(pid);
		ModelAndView mv = new ModelAndView();
		mv.addObject("product", product);
		mv.setViewName("admin/product/edit");
		return mv;
	}
	@RequestMapping("/findUserProductById")
	public ModelAndView findUserProductById(int pid) {
		Product product=productService.findProductById(pid);
		ModelAndView mv = new ModelAndView();
		mv.addObject("p", product);
		mv.setViewName("/jsp/desc.jsp");
		return mv;
	}
	@RequestMapping("/editProduct")
	public String editProduct(Product product,MultipartFile pictureFile) {
		System.out.println(product);
		String result=null;
		if (!"".contentEquals(pictureFile.getOriginalFilename())) {
			result = uploadMultipartFile(pictureFile);
			product.setImage(result);
			
		}
		if (!("error".equals(result))&&result!=null) {
			productService.editProduct(product);
		}

		return "redirect:findProductByPage.action";
	}
	
	@RequestMapping("/findAllHotProductAjax")
	@ResponseBody
	public List<Product> findAllHotProductAjax() {
		List<Product> list=productService.findAllHotProduct();
		return list;
	}
	@RequestMapping("/findAllNewProductAjax")
	@ResponseBody
	public List<Product> findAllNewProductAjax() {
		List<Product> list=productService.findAllNewProduct();
		return list;
	}
	@RequestMapping("/findProductsByfid")
	@ResponseBody
	public List<Product> findProductsByfid(int fid){
		List<Product> list=productService.findProductsByfid(fid);
		return list;
	}

	@RequestMapping("/upload")
	public String uploadMultipartFile(MultipartFile pictureFile) {
		String filename = pictureFile.getOriginalFilename();//
		// 使用UUID给图片命名
		String newFileName = UUID.randomUUID().toString() + filename.substring(filename.lastIndexOf("."));
		// 磁盘地址
		File dest = new File("D:/mvc/uploads/" + newFileName);
		try {
			// 将图片保存在磁盘上，上传成功
			pictureFile.transferTo(dest);
			return newFileName;
		} catch (Exception e) {
			// 上传失败
			e.printStackTrace();
		}
		return "error";
	}

}
